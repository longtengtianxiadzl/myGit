package com.pbdevj.oop;

public class StudentTest
{

	public static void main(String[] args)
	{
		Student student = new Student();
		
		student.learning();
	}

}
