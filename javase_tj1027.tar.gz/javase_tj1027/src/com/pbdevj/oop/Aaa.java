package com.pbdevj.oop;

public interface Aaa
{
   
}
