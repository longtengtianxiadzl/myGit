package com.pbdevj.oop;

public class PersonTest
{
	public static void main(String[] args)
	{
//		Person person = new Person(110, "zhangsan", 23);

//		person.id = 110;
//
//		person.name = "zhangsan";
//
//		person.age = 23;
//
//		//对象信息的输出
//		System.out.println(person.id + ">>" + person.name + ">>" + person.age);
		
		
		
//		person.setId(111111);
		
//		person.setName("wangwu");
//		
//		person.setAge(32);
//		
//		String name = person.getName();
//		
//		System.out.println(person/*.toString()*/);

//		String result = person.eat("米");
		
//		System.out.println(result);
		
//		person.eat(12);
	}
}
