package com.pbdevj.oop;

public interface Bbb
{

}
