package com.pbdevj.oop2;

public class PloyTest
{

	public static void main(String[] args)
	{
		Person s_Person = new Student();
		
		Person t_Person = new Teacher();
		
		Task task = new Task();
		
		task.eat(t_Person);

	}

}
