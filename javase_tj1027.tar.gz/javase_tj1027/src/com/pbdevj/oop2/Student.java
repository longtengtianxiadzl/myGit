package com.pbdevj.oop2;

public class Student extends Person
{
    public void leaning()
    {
    	System.out.println("学生学习");
    }
}
