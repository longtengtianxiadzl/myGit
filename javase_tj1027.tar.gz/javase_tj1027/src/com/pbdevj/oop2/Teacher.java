package com.pbdevj.oop2;

public class Teacher extends Person
{
    public void teaching()
    {
    	System.out.println("老师教课");
    }
}
