package com.pbdevj.oop2;

public class Person
{

}
