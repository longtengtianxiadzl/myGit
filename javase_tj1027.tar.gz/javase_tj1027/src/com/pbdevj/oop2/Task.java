package com.pbdevj.oop2;

public class Task
{
	public void eat(Person person)// Person person = student;
	{
		 System.out.println(person + "在吃饭");
	
	}
}
