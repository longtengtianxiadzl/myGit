package com.pbdevj.advanced_future.annotation;

@MyAnnotation(value="zhangsan", number = 123)
public class World
{

}
