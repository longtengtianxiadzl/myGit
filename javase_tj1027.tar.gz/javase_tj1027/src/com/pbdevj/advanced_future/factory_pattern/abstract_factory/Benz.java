package com.pbdevj.advanced_future.factory_pattern.abstract_factory;

//抽象工厂角色
public abstract class Benz
{
	public abstract void createBenz();
}
