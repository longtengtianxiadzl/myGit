package com.pbdevj.advanced_future.factory_pattern.abstract_factory;

//抽象产品
public abstract class Maybach
{
	public abstract void createMaybach();
}
