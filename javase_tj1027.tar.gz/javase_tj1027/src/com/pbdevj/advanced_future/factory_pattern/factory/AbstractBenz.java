package com.pbdevj.advanced_future.factory_pattern.factory;

//抽象产品角色
public abstract class AbstractBenz
{
	public AbstractBenz()
	{
		
	}
}
