package com.pbdevj.advanced_future.factory_pattern.factory;

//具体产品角色
public class Benz600 extends AbstractBenz
{

	public Benz600()
	{
		System.out.println("制造奔驰600");
	}

}
