package com.pbdevj.advanced_future.factory_pattern.factory;

//抽象工厂类
public abstract class AbstractBenzFactory
{
	public abstract AbstractBenz createBenz();
}
