package com.pbdevj.advanced_future.factory_pattern.factory;

// 具体产品角色
public class BenzGLK extends AbstractBenz
{
	public BenzGLK()
	{
		System.out.println("制造奔驰GLK");
	}
}
