package com.pbdevj.advanced_future.factory_pattern.simple_factory;

public class Chinese implements IPerson
{

	@Override
	public void sayHi()
	{
		System.out.println("中国人说中文");
	}
}
