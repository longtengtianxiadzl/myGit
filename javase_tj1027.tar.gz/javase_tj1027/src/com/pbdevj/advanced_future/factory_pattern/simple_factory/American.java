package com.pbdevj.advanced_future.factory_pattern.simple_factory;

public class American implements IPerson
{
	@Override
	public void sayHi()
	{
		System.out.println("美国人说英文");
	}
}
