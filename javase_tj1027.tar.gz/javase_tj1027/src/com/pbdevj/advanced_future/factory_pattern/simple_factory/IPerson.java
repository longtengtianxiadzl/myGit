package com.pbdevj.advanced_future.factory_pattern.simple_factory;

public interface IPerson
{
	 public void sayHi();
}
