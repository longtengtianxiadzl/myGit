package com.pbdevj.advanced_future.collection;

public class Null
{
	public static void hello()
	{
		System.out.println("hello");
	}

	public static void main(String[] args)
	{
    ((Null)null).hello();
       
       Null _null = null;
       
       _null.hello();
	}

}
