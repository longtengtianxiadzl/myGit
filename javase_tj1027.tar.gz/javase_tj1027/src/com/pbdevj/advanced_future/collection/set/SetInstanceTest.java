package com.pbdevj.advanced_future.collection.set;

public class SetInstanceTest
{
	public static void main(String[] args)
	{
		SetInstance si = new SetInstance();
		
//		si.testHashSet();
		
//		si.testTreeList();
		
		si.testTreeList2();
	}
}
