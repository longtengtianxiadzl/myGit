package com.pbdevj.advanced_future.collection.map;

public class MapInstanceTest

{
	
	public static void main(String[] args)
	{
		MapInstance mi = new MapInstance();
		
//		mi.testHashtable();
		
//		mi.testHashMap();
		
		mi.testTreeMap();
	}
}
