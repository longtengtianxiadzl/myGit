package com.pbdevj.advanced_future.collection.list;

public class ListInstanceTest
{
	public static void main(String[] args)
	{
		ListInstance li = new ListInstance();
		
//		li.testVector();
		
//		li.testVector2();
		
//		li.testArrayList();
		
//		li.testLinkedList();
		
		li.testArrayListByDefinitedObj2();
	}
}
