package com.pbdevj.advanced_future.multi_thread.impl.etends_thread2;

public class Myte
{
	int a;

	public int getA()
	{
		return a;
	}

	public void setA(int a)
	{
		this.a = a;
	}
	
}
