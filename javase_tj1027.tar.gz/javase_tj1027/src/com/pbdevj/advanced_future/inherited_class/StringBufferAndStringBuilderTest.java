package com.pbdevj.advanced_future.inherited_class;

public class StringBufferAndStringBuilderTest
{
	public static void main(String[] args)
	{
        StringBuilder sb = new StringBuilder();
        
        sb.append("abc").append("ab");
        
//        System.out.println(sb.reverse());
        
//         System.out.println(RandomStringUtils.randomAlphanumeric(10));
        
        
        
	}
}
