 package com.pbdevj.advanced_future.proxy.dynamic_proxy;

//抽象主题角色：要完成的任务
public interface ISubject
{
    public void doTask(String str);
}
