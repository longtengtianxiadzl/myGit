package com.pbdevj.advanced_future.proxy.dynamic_proxy;

public class AdditionalFuncation
{
	public void before()
	{
		System.out.println("租房子之前配齐家电");
	}
	
	
	public void after()
	{
		System.out.println("租房子之后介绍个对象");
	}
}
