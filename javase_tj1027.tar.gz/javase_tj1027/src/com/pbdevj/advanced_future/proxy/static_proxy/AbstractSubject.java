package com.pbdevj.advanced_future.proxy.static_proxy;

//抽象主题角色：要完成的任务
public abstract class AbstractSubject
{
    public abstract void doTask();
}
