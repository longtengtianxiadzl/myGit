package com.pbdevj.oop3;

public class Fruit
{
	public Person eatFruit(Person person)//person = student;
	{
       System.out.println(person + "吃完水果");
        
       return person;
	}
}
