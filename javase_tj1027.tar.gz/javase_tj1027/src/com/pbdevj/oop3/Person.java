package com.pbdevj.oop3;

public class Person
{
    public void eat()
    {
    	System.out.println("人吃饭");
    }
    
    public void running()
    {
    	System.out.println("跑");
    }
	
}
