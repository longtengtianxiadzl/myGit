package com.pbdevj2;

public class Hello
{
    public String sayHello()
    {
    	return "hello";
    }
}
