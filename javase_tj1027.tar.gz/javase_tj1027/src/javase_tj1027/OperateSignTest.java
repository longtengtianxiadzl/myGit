package javase_tj1027;

public class OperateSignTest
{
	public static void main(String[] args)
	{
	    int num = 5;
	    
	    int num2 = 3;
	    
	    double num3 = 5.0;
	    
//	    System.out.println(num3 / num2);
	    
//	    System.out.println(-num % num2);
	    
//	    int result = num--;
//	    
//	    System.out.println("result = " + result);
//	    
//	    System.out.println("num = " + num);
	    
//	    System.out.println("num = " + num);
	    
//	    System.out.println(!false);
	    
//	    System.out.println(num < num2 && ++num2 < 5);
//	    
//	    System.out.println(num2);
	    
//	    System.out.println(num < num2 & ++num2 < 5);
//	    
//	    System.out.println(num2);
	    
	    int res = num > num2 ? 1 : 0;
	    
	   // System.out.println(res);
	    
	    double r = -4.0 / 0;
	    
//	    System.out.println(r);
	    
	    short sNum = 1;
	    
	    sNum += 1;//sNum = (short)(sNum + 1);
	    
	    
	    
	}
}
