package javase_tj1027;

/**
 * 这是一个测试类
 *
 */
public class Hello
{
	/**
	 * 这是一个程序的入口
	 *
	 */
	public static void main(String[] args)
	{
		//练习打印输出语句
		System.out.println("hello");
		/*System.out.println("hello");
		System.out.println("hello");*/
	}
}
