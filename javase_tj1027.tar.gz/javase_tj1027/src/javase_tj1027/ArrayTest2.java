package javase_tj1027;

import java.util.Arrays;

public class ArrayTest2
{

	public static void main(String[] args)
	{
		int[] intArr = {9, 3, 2, 6, 1}; 
		
//		int[] intArr = new int[5];
		
//		Arrays.fill(intArr, 33);
		
		System.out.println(intArr);
		
		System.out.println(Arrays.toString(intArr));
		
//		int[] resultArr = Arrays.copyOf(intArr, 10);
		
//		int[] resultArr = Arrays.copyOfRange(intArr, 1, 4);
		
//		System.out.println(Arrays.toString(resultArr));
		
//		Arrays.sort(intArr);//
//		
//		System.out.println(Arrays.binarySearch(intArr, 3));

	}

}
